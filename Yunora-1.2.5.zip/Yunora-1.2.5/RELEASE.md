Release v1.2.5
Download installers from the releases page.
